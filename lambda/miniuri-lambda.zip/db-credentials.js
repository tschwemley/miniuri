'use strict'

module.exports = {
  host: 'db.tylerschwemley.com',
  user: 'tjschwem',
  password: 'foosbAll8230*',
  database: 'miniuri'
}
